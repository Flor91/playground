package com.manning.hip.ch11;

import org.apache.pig.EvalFunc;
import org.apache.pig.data.Tuple;

import java.io.IOException;

/**
 */
public class NonAlgebraic extends EvalFunc<String> {

  public String exec(Tuple input) throws IOException {
    return null;
  }
}
