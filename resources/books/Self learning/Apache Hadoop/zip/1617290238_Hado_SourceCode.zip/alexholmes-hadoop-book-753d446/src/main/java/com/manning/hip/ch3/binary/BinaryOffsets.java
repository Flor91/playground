package com.manning.hip.ch3.binary;

public class BinaryOffsets {
}
